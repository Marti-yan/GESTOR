import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    host: "127.0.0.1",
    port: 5173,
    proxy: {
      "/api": "http://127.0.0.1:4317",
      "/manifest.webmanifest": "http://127.0.0.1:4317",
      "/garcom.webmanifest": "http://127.0.0.1:4317",
      "/entregador.webmanifest": "http://127.0.0.1:4317",
      "/sw.js": "http://127.0.0.1:4317",
    },
  },
  build: { outDir: "dist", sourcemap: false },
});
