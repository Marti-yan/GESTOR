import { useEffect, useState } from "react";
import { api } from "./api";
type State = {
  loggedIn: boolean;
  identity: { name: string; companyId: string; userId: string } | null;
  socketConnected: boolean;
  syncing?: boolean;
  lastSync: string | null;
  error: string;
};
export function AtendeSetup({
  connectionId,
  onSelect,
}: {
  connectionId: string;
  onSelect: (id: string) => Promise<void>;
}) {
  const [state, setState] = useState<State | null>(null),
    [connections, setConnections] = useState<
      { id: string; name: string; status: string }[]
    >([]),
    [email, setEmail] = useState(""),
    [password, setPassword] = useState(""),
    [busy, setBusy] = useState(false),
    [message, setMessage] = useState("");
  const load = async () => {
    const r = await api<{ atende: State }>("/admin/whatsapp");
    setState(r.atende);
    if (r.atende.loggedIn)
      setConnections(
        (
          await api<{ connections: typeof connections }>(
            "/admin/whatsapp/atende/connections",
          )
        ).connections,
      );
  };
  useEffect(() => {
    let active = true;
    load().catch((e) => {
      if (active) setMessage(e.message);
    });
    const timer = setInterval(
      () =>
        api<{ atende: State }>("/admin/whatsapp")
          .then((r) => {
            if (active) setState(r.atende);
          })
          .catch((e) => {
            if (active) setMessage(e.message);
          }),
      5000,
    );
    return () => {
      active = false;
      clearInterval(timer);
    };
  }, []);
  async function action(fn: () => Promise<unknown>, success: string) {
    setBusy(true);
    try {
      await fn();
      await load();
      setMessage(success);
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "Não foi possível concluir.");
    } finally {
      setBusy(false);
    }
  }
  return (
    <section className="operation-panel">
      <h3>Acessar Atende Chat</h3>
      <p>
        Salve o endereço do backend acima e entre com sua conta. O WhatsApp
        continua conectado no Atende Chat.
      </p>
      {!state?.loggedIn ? (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            action(async () => {
              await api("/admin/whatsapp/atende/login", "POST", {
                email,
                password,
              });
              setPassword("");
            }, "Conta conectada. Selecione o número abaixo.");
          }}
        >
          <label className="field">
            E-mail do Atende Chat
            <input
              type="email"
              autoComplete="username"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </label>
          <label className="field">
            Senha do Atende Chat
            <input
              type="password"
              autoComplete="current-password"
              required
              maxLength={256}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </label>
          <button className="button primary" disabled={busy}>
            Entrar no Atende Chat
          </button>
        </form>
      ) : (
        <>
          <p>
            <strong>{state.identity?.name}</strong> ·{" "}
            {state.socketConnected
              ? "Tempo real conectado"
              : "Sincronização pela API"}
          </p>
          <label className="field">
            Número conectado no Atende Chat
            <select
              aria-label="Número conectado no Atende Chat"
              value={connectionId}
              disabled={busy}
              onChange={(e) =>
                action(() => onSelect(e.target.value), "Conexão selecionada.")
              }
            >
              <option value="">Selecione</option>
              {connections.map((c) => (
                <option value={c.id} key={c.id}>
                  {c.name} · {c.status}
                </option>
              ))}
            </select>
          </label>
          <div className="operation-actions">
            <button
              className="button primary"
              disabled={busy || !connectionId || state.syncing}
              onClick={() =>
                action(
                  () => api("/admin/whatsapp/atende/sync", "POST", {}),
                  "Sincronização iniciada. Os tickets aparecerão na lista de conversas.",
                )
              }
            >
              Sincronizar tickets agora
            </button>
            <button
              className="button secondary"
              disabled={busy}
              onClick={() =>
                action(async () => {
                  await api("/admin/whatsapp/atende/forget", "POST");
                  setConnections([]);
                }, "Gestor desvinculado. O WhatsApp continua no Atende Chat.")
              }
            >
              Desvincular este gestor
            </button>
          </div>
          {state.lastSync && (
            <small>
              Última sincronização:{" "}
              {new Date(state.lastSync).toLocaleString("pt-BR")}
            </small>
          )}
          {state.syncing && <p role="status">Sincronizando tickets…</p>}
          {state.error && <p role="alert">{state.error}</p>}
          <p>
            Em uma conversa, assumir pausa os robôs do Atende Chat. Ativar o
            agente do gestor usa a IA cadastrada aqui. Para devolver ao fluxo
            original, use o Atende Chat.
          </p>
        </>
      )}
      <p role="status">{message}</p>
    </section>
  );
}
